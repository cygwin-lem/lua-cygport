/usr/sbin/alternatives \
  --install /usr/bin/lua \
    lua /usr/bin/lua5.2 \
    502 \
  --slave /usr/bin/luac \
    luac /usr/bin/luac5.2 \
  --slave /usr/share/man/man1/lua.1.gz \
    lua.1.gz /usr/share/man/man1/lua5.2.1.gz \
  --slave /usr/share/man/man1/luac.1.gz \
    luac.1.gz /usr/share/man/man1/luac5.2.1.gz \
  --slave /usr/lib/pkgconfig/lua.pc \
    lua.pc /usr/lib/pkgconfig/lua5.2.pc \
  ;
