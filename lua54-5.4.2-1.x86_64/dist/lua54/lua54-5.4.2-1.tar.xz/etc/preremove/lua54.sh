/usr/sbin/alternatives \
  --remove \
    lua /usr/bin/lua5.4 \
  ;
